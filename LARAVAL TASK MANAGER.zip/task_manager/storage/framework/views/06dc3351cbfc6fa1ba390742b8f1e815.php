Dear <?php echo e($data->task_owner); ?>,<br><br>
The Task <b><?php echo e($data->task_description); ?></b>, <?php echo e($data->status==0? "has been added for you":"Has been Marked As Completed"); ?>

<br><br><?php if($data->status==0): ?>
Kindly complete it within <b><?php echo e($data->task_eta); ?></b>,
<?php endif; ?>
<br><br>Thank You
<?php /**PATH C:\Users\91944\OneDrive\Desktop\project 2\task_manager\resources\views/email/notification.blade.php ENDPATH**/ ?>