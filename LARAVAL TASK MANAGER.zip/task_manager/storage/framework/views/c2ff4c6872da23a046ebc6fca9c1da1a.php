
<?php $__env->startSection('title','All Tasks'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('style'); ?>
<style>
    .done{
        text-decoration: line-through;
    }
</style>
<?php $__env->stopSection(); ?>
    <?php echo $__env->make('layout.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container mt-5">
            <button type="button" class="btn btn-outline-primary mb-5 end-0" onclick="addTask()">Add Tasks</button>
            <div class="card"> 
                <div class="class-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">SNo.</th>
                                <th scope="col">Task Description</th>
                                <th scope="col">Task Owner</th>
                                <th scope="col">Task ETA</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody id="taskTable">
                            

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
<!----------------------------------------------------------------------------------------------------------------------------->
<div class="modal fade" id="createTaskModal" tabindex="-1" style="
    opacity: 1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Task</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
            <form>
                <div class="form-group">
                    <lable for="createTaskDescription">Task Description</lable>
                    <input type="text" class="form-control" id="createTaskDescription" placeholder="Enter Task Description">
                </div>
                <div class="form-group">
                    <lable for="createTaskDescription">Task Owner</lable>
                    <input type="text" class="form-control" id="createTaskOwner" placeholder="Enter Task Owner">
                </div>
                <div class="form-group">
                    <lable for="createTaskDescription">Owner Email</lable>
                    <input type="text" class="form-control" id="createTaskEmail" placeholder="Enter Task Owner Email">
                </div>
                <div class="form-group">
                    <lable for="createTaskDescription">Task ETA</lable>
                    <input type="date" class="form-control" id="createTaskETA" placeholder="Enter Task ETA">
                </div>
            </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="createTask()">Add</button>
            </div>

        </div>
    </div>
</div>
<!----------------------------------------------------------------------------------------------------------------------------->
<div class="modal fade" id="editTaskModal" tabindex="-1" style="
    opacity: 1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Task</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
            <form>
                <div class="form-group">
                    <lable for="editTaskDescription">Task Description</lable>
                    <input type="text" class="form-control" id="editTaskDescription" placeholder="Enter Task Description">
                </div>
                <div class="form-group">
                    <lable for="editTaskDescription">Task Owner</lable>
                    <input type="text" class="form-control" id="editTaskOwner" placeholder="Enter Task Owner">
                </div>
                <div class="form-group">
                    <lable for="editTaskDescription">Owner Email</lable>
                    <input type="text" class="form-control" id="editTaskEmail" placeholder="Enter Task Owner Email">
                </div>
                <div class="form-group">
                    <lable for="editTaskDescription">Task ETA</lable>
                    <input type="text" class="form-control" id="editTaskETA" placeholder="Enter Task ETA">
                </div>
                
                <div class="form-group">
                    <lable for="editTaskStatus">Task Status</lable>
                    <select class="form-control" id="editTaskStatus">
                        <option value= 0>In Progress</option>
                        <option value= 1>Done</option>
                    </select>
                </div>
                <input type="hidden" id="editTaskid">
            </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="updateTask()">Save</button>
            </div>

        </div>
    </div>
</div>
<!-----------------------------------------------------------------------------------------------------------------------------> 
<!----------------------------------------------------------------------------------------------------------------------------->
<div class="modal fade" id="doneTaskModal" tabindex="-1" style="
    opacity: 1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Mark as Done</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Did You Finish The Task?</p>
            <input type="hidden" id="doneTaskid">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="updateMarkAsDone()">Mark</button>
            </div>

        </div>
    </div>
</div>
<!-----------------------------------------------------------------------------------------------------------------------------> 
<div class="modal fade" id="deleteTaskModal" tabindex="-1" style="
    opacity: 1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Delete task</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure You want to Delete the Task?</p>
            <input type="hidden" id="deleteTaskid">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="updateDelete()">Yes</button>
            </div>

        </div>
    </div>
</div>
<!-----------------------------------------------------------------------------------------------------------------------------> 

<?php $__env->stopSection(); ?>
<?php $__env->startSection('customjs'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
  <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script>
    $(document).ready(function(){
        getAllTasks();
    });
/*--------------------------------------------------------------------------------------------------------------------------------- */
function getAllTasks(){
$.ajax({
    type:'get',
    url:'http://localhost:8000/api/task',
    success:function(result){
        var html = '';
        for(var i=0;i<result.length;i++){
            var lineThrough= result[i]['status']==1?'class="done"': "";
           html += ' <tr>'+
                                '<th scope="row" '+lineThrough+'>'+ (i+1)+'</th>'+
                                '<td '+lineThrough+'>' +result[i]['task_description']+'</td>'+
                                '<td '+lineThrough+'>' +result[i]['task_owner']+'</td>'+
                                '<td '+lineThrough+'>' +result[i]['task_eta']+'</td>'+
                                '<td>'+
                                    '<i class="bi bi-pencil-square" onclick="editTask('+result[i]['id']+')"></i>'+
                                    '<i class="bi bi-check2-square" onclick="markasdone('+result[i]['id']+')"></i>'+
                                    '<i class="bi bi-trash" onclick="deletetask('+result[i]['id']+')"></i>'+
                                '</td>'+
                            '</tr>'

        }
        $("#taskTable").html(html)
    },
    error:function(e){
        console.log(e.responseText) 
    }
})
}
/*--------------------------------------------------------------------------------------------------------------------------------- */
function addTask(){
    $("#createTaskModal").modal('show');
}
function createTask(){
    var task_description= $("#createTaskDescription").val()
    var task_owner= $("#createTaskOwner").val()
    var task_owner_email= $("#createTaskEmail").val()
   var task_eta= $("#createTaskETA").val()
   $.ajax({
    type:'post',
    url:'http://localhost:8000/api/task',
    data: {
        task_description:task_description,
        task_owner:task_owner,
        task_owner_email:task_owner_email,
        task_eta:task_eta

    },
    success:function(result){
        $("#createTaskModal").modal('hide');
        getAllTasks();
    },
    error:function(e){
        console.log(e.responseText) ;
    }
})
}
/*--------------------------------------------------------------------------------------------------------------------------------- */
function editTask(id){
    
    $.ajax({
    type:'get',
    url:'http://localhost:8000/api/task/'+id,
    success:function(result){
    $("#editTaskDescription").val(result['task_description']);
    $("#editTaskOwner").val(result['task_owner']);
    $("#editTaskEmail").val(result['task_owner_email']);
    $("#editTaskETA").val(result['task_eta']);
    $("#editTaskStatus").val(result['status']);
    $("#editTaskid").val(result['id']);
    $("#editTaskModal").modal('show');
    },   
    error:function(e){
        console.log(e.responseText) 
    }
})
}
function updateTask(){
    var id=$("#editTaskid").val()
    var task_description= $("#editTaskDescription").val()
    var task_owner= $("#editTaskOwner").val()
    var task_owner_email= $("#editTaskEmail").val()
   var task_eta= $("#editTaskETA").val()
   var task_status= $("#editTaskStatus").val();
   $.ajax({
    type:'put',
    url:'http://localhost:8000/api/task/'+id,
    data: {
        task_description:task_description,
        task_owner:task_owner,
        task_owner_email:task_owner_email,
        task_eta:task_eta,
        task_status:status,

    },
    success:function(result){
        $("#editTaskModal").modal('hide');
        getAllTasks();
    },
    error:function(e){
        console.log(e.responseText) ;
    }
})
}

/*--------------------------------------------------------------------------------------------------------------------------------- */
function markasdone(id){
    $("#doneTaskid").val(id)
    $("#doneTaskModal").modal('show')
}

function updateMarkAsDone(){
    var id=$("#doneTaskid").val()
   
   $.ajax({
    type:'post',
    url:'http://localhost:8000/api/task/done/'+id,
    
    success:function(result){
        $("#doneTaskModal").modal('hide');
        getAllTasks();
    },
    error:function(e){
        console.log(e.responseText) ;
    }
})

}
/*--------------------------------------------------------------------------------------------------------------------------------- */

function deletetask(id){
    $("#deleteTaskid").val(id)
    $("#deleteTaskModal").modal('show')
}
function updateDelete(){
    var id=$("#deleteTaskid").val()
   
   $.ajax({
    type:'delete',
    url:'http://localhost:8000/api/task/'+id,
    
    success:function(result){
        $("#deleteTaskModal").modal('hide');
        getAllTasks();
    },
    error:function(e){
        console.log(e.responseText) ;
    }
})

}
/*--------------------------------------------------------------------------------------------------------------------------------- */
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.baseview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\91944\OneDrive\Desktop\project 2\task_manager\resources\views/task/index.blade.php ENDPATH**/ ?>