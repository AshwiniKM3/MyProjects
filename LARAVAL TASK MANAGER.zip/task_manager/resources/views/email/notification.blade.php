Dear {{$data->task_owner}},<br><br>
The Task <b>{{$data->task_description}}</b>, {{$data->status==0? "has been added for you":"Has been Marked As Completed"}}
<br><br>@if($data->status==0)
Kindly complete it within <b>{{$data->task_eta}}</b>,
@endif
<br><br>Thank You
