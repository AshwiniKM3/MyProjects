<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todo_list";
$conn = new mysqli($servername, $username, $password, $dbname);
if(!$conn){
 die('Could not Connect MySql:' .mysqli_connect_error());
}
?>