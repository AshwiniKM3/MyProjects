<?php 
include 'connection.php';
if(isset($_POST['add']))
{
   $task = $_POST['task'];

   if(!empty($task)){
   $query= "INSERT INTO todo (task) values('$task')";
   if(mysqli_query($conn,$query)){
    echo'<center><div class="alert alert-success" role="alert"> Task Added Successfully</div></center>';
   }
   else{echo mysqli_error($conn);}
  }
}
/*---------------------------------------------------------------------------------------------------------------------------------------------------- */
if(isset($_GET['action']))
{
   $taskId = $_GET['task'];
/*to mark as Done*/ 
   if($_GET['action']=='done'){
   $query= "UPDATE todo SET task_status =1 WHERE id= '$taskId'";
   if(mysqli_query($conn,$query)){
    echo'<center><div class="alert alert-info" role="alert"> Task marked as Done</div></center>';
   }
   else{echo mysqli_error($conn);}
  }
  /*to Delete*/ 
  elseif($_GET['action']=='delete'){
    $query="DELETE FROM todo WHERE id='$taskId'";
    if(mysqli_query($conn,$query)){
        echo'<center><div class="alert alert-danger" role="alert"> Task Deleted Successfully</div></center>';
       }
       else{echo mysqli_error($conn);}
  }
  /*to mark as Not Done if already marked as done*/ 
  elseif($_GET['action']=='notDone'){
    $query= "UPDATE todo SET task_status =0 WHERE id= '$taskId'";
    if(mysqli_query($conn,$query)){
     echo'<center><div class="alert alert-info" role="alert"> Task marked as Not Done</div></center>';
    }
    else{echo mysqli_error($conn);}
   }
  
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Your To-Do List </title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
<style>
    .cardHeader{
        padding: 20px 20px;
        text-align: center;
    }
    .cardBody{
        padding: 10px 10px;
        align-items: center;

    }
    .done{
        text-decoration: line-through;

    }
    .notDone{
        text-decoration: none;

    }
</style>
    </head>
    <body>
    
    <main>
        <div class="container pt-5">
            <div class="row">
                <div class="col-sm-12 col-md-3"></div>
                <div class="col-sm-12 col-md-6">
                <div class="card">
                    <div class="cardHeader">
                       <p>Your Task List</p>
                    </div>
                    <div class="cardBody">
                       <form action="<?=$_SERVER['PHP_SELF']?>" method="POST">
                        <div class="mb-3">
                            <input type="text" class="form-control" name="task" placeholder="Add New Task ">
                        </div>
                        <input type="submit" class="btn btn-dark" name="add" value="Add">
                       </form>
                       <div class="mt-5 mb-5">
                           
                           <?php 
                           $info= "SELECT * FROM todo ";
                           $mydata= mysqli_query($conn,$info);
                           
                           if($mydata->num_rows>0)
                           {
                            $i=1;
                            while($row = $mydata->fetch_assoc()){
                                $done= $row['task_status']==1 ? "done": "notDone";
                            echo '<div class="row">';
                            echo'
                            <div class="col-sm-12 col-md-1"><h5>'.$i.'</h5></div>
                            <div class="col-sm-12 col-md-6"><h5 class="'.$done.'">'.$row['task'].'</h5></div>
                            ';
                            if($done=="done"){echo'<div class="col-sm-12 col-md-5">
                                <a href="?action=notDone&task='.$row['id'].'" class ="btn btn-outline-dark">Undo</a>
                                <a href="?action=delete&task='.$row['id'].'" class ="btn btn-outline-danger">Delete</a>
                              </div>';}
                              else{echo'<div class="col-sm-12 col-md-5">
                                <a href="?action=done&task='.$row['id'].'" class ="btn btn-outline-dark">Done</a>
                                <a href="?action=delete&task='.$row['id'].'" class ="btn btn-outline-danger">Delete</a>
                              </div>';}
                              echo '</div>';
                             $i++;}}
                            else{echo'<center>
                                <img src="image/file.png" width="50px" alt="No tasks Yet"><br><Span> Your List is empty</span>
                            </center>';}
                           
                           ?>
                           

                           
                           
                       </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
<script>
    $(document).ready(function(){
        $(".alert").fadeTo(5000,500).slideUp(500,function(){
            $('.alert').slideUp(500);
        })
    })
</script>
    </body>
</html>