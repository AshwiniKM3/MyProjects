<?php
if(!isset($_SESSION['userName'])){
    echo "Not logged in: <a href= login.php>Login</a><a href=register.php>Register></a>";}

?>