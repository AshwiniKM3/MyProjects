const dragArea = document.querySelector('.drag-area');
const dragText = document.querySelector('.header');
const button = document.querySelector('.button');
const input = document.querySelector('input');
const form = document.querySelector('form'); // Reference the form
const submitButton = document.querySelector('#submit-button'); // Reference the submit button

button.onclick = () => {
  input.click();
};

input.addEventListener('change', function() {
  file = this.files[0];
  // Perform validation and display changes
  submitForm();
});

dragArea.addEventListener('dragover', (event) => {
  event.preventDefault();
  dragText.textContent = 'Release to upload';
  dragArea.classList.add('active');
});

dragArea.addEventListener('dragleave', () => {
  dragText.textContent = 'Drag & Drop';
  dragArea.classList.remove('active');
});

dragArea.addEventListener('drop', (event) => {
  event.preventDefault();
  file = event.dataTransfer.files[0];
  // Perform validation and display changes
  submitForm();
});

  function submitForm() {
  let fileType = file.type;
  let validExtensions = ['application/pdf'];

  if (validExtensions.includes(fileType)) {
    const fileNameDisplay = document.querySelector('#file-name');
    fileNameDisplay.textContent = `You have selected ${file.name}`;

    const dragArea = document.querySelector('.drag-area');
    const afterUpload = document.querySelector('.afterUpload');

    dragArea.style.display = "none"; // Hide drag-area
    afterUpload.style.display = "block"; // Show afterUpload section
  } else {
    alert('This file is not Supported');
    dragArea.classList.remove('active');
  }
}
submitButton.addEventListener('click', () => {
  if (file) { // Ensure a file has been selected before submitting
    form.submit();
  } else {
    alert('Please select a file first.');
  }
});
