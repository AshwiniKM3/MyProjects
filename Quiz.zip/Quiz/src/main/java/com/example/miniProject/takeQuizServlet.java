package com.example.miniProject;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
@WebServlet("/takeQuizServlet")
public class takeQuizServlet extends HttpServlet {
	@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        try {
			processRequest(request, response);
		} catch (ServletException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        try {
			processRequest(request, response);
		} catch (ServletException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException, SQLException {

        

		Connection conn = DatabaseManager.getConnection();
        try  {
        	String quizName = request.getParameter("FName");
        	String tableName= "quiz_" + quizName.replaceAll("\\W+", "_");
             
            HashSet<HashMap<String, Object>> questionSet = new HashSet<>();	
            List<String> Answers = new ArrayList<String>();
    		List<String> Questions = new ArrayList<String>();
    		List<List<String>> Options = new ArrayList<List<String>>();
        	PrintWriter pw = response.getWriter();
        	   PreparedStatement stmt = conn.prepareStatement("SELECT question, options, Answer FROM "+tableName);
            //   stmt.setString(1, tableName); 
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
            	List<String> op= new ArrayList<String>();
                String question = rs.getString("question");
                String[] options = rs.getString("options").split(",");
                for(int i=0;i<options.length;i++) {
                	op.add(options[i]);
                }
                
                String answer = rs.getString("answer");
Answers.add(answer);
Questions.add(question);
Options.add(op);
             
            }
            for(int i=0;i<Answers.size();i++) {
    			HashMap<String, Object> question1 = new HashMap<>();  
    			question1.put("question", Questions.get(i));
    			question1.put("options", Options.get(i));
    			question1.put("answer", Answers.get(i));
    			questionSet.add(question1);
    		}
            
            Gson gson = new Gson();
            String jsonData = gson.toJson(questionSet);
            

            request.setAttribute("name",tableName);
            request.setAttribute("questions",jsonData);
           RequestDispatcher dispatcher = request.getRequestDispatcher("/fileUpload1.jsp");
            dispatcher.forward(request, response);

        } catch (Exception e) {
            System.out.print(e);}
       finally {
            if (conn != null) {
                try {
                    conn.close();  // Close connection here
                } catch (SQLException e) {
                    // Handle any errors during connection closing
                    System.out.println("Error closing connection: " + e);
                }
            }
        }
   
       
        
    }}

