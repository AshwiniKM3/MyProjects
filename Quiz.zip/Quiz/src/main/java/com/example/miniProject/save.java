package com.example.miniProject;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/save")
public class save extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");

        if (username == null || username.isEmpty()) {
            // Redirect to login page or handle the scenario where username is not available
            response.sendRedirect("login.jsp");
            return;
        }

        // Retrieve score from request parameter
        String score = request.getParameter("score");
        String name = request.getParameter("name");
        saveIntoQuizScoreTable(username, name, score);
        saveScoreAndTimestamp(username,name, score);

        // Send response back to client
        response.setContentType("text/html"); // Set content type to HTML
        PrintWriter out = response.getWriter();
        // Print HTML response with styles
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Score Saved</title>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; background-color: black; color: white; }");
        out.println(".message { color: green; font-size: 20px;}");
        out.println("a { text-decoration: none; color: #00BFFF; }"); // Link color
        out.println("a:hover { color: #87CEFA; }"); // Hover color for links
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='message'>Score saved successfully!</div>");
        out.println("<a href='fileUpload1.jsp'>Go Back to Test</a>");
        out.println("</body>");
        out.println("</html>");

    }
    private void saveIntoQuizScoreTable(String username, String name, String score) {
        Connection connection = null;
        PreparedStatement statement = null;

        try {
            // Establish database connection (replace with your database connection logic)
            connection = DatabaseManager.getConnection();

            // Check if table exists, create it if not
            createQuizScoreTableIfNotExists(connection, name);

            // Insert username and score into the table
            String sql = "INSERT INTO " + name + "_score (username, score) VALUES (?, ?)";
            statement = connection.prepareStatement(sql);
            statement.setString(1, username);
            statement.setString(2, score);

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle exception appropriately
        } finally {
            // Close resources
            try {
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace(); // Handle exception appropriately
            }
        }
    }

    private void createQuizScoreTableIfNotExists(Connection connection, String name) throws SQLException {
        // Check if table exists
        String tableName = name + "_score";
        String checkTableExistsSql = "SHOW TABLES LIKE ?";
        PreparedStatement checkStatement = connection.prepareStatement(checkTableExistsSql);
        checkStatement.setString(1, tableName);
        if (!checkStatement.executeQuery().next()) {
            // Table does not exist, create it
            String createTableSql = "CREATE TABLE " + tableName + " (id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "username VARCHAR(50), score VARCHAR(20))";
            PreparedStatement createStatement = connection.prepareStatement(createTableSql);
            createStatement.executeUpdate();
        }
    }

    private void saveScoreAndTimestamp(String username,String name, String score) {
        Connection connection = null;
        PreparedStatement statement = null;

        try {
            // Establish database connection (replace with your database connection logic)
            connection = DatabaseManager.getConnection();

            // Check if table exists, create it if not
            createReportTableIfNotExists(connection, username);

            // Insert score and timestamp into the table
            String sql = "INSERT INTO report_" + username + " (name,score, timestamp) VALUES (?,?, now())";
            statement = connection.prepareStatement(sql);
            statement.setString(1, name);
            statement.setString(2, score);

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle exception appropriately
        } finally {
            // Close resources
            try {
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace(); // Handle exception appropriately
            }
        }
    }

    private void createReportTableIfNotExists(Connection connection, String username) throws SQLException {
        // Check if table exists
        String tableName = "report_" + username;
        String checkTableExistsSql = "SHOW TABLES LIKE ?";
        PreparedStatement checkStatement = connection.prepareStatement(checkTableExistsSql);
        checkStatement.setString(1, tableName);
        if (!checkStatement.executeQuery().next()) {
            // Table does not exist, create it
            String createTableSql = "CREATE TABLE " + tableName + " (id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "score VARCHAR(20), timestamp TIMESTAMP, name VARCHAR(20))";
            PreparedStatement createStatement = connection.prepareStatement(createTableSql);
            createStatement.executeUpdate();
        }
    }
}
