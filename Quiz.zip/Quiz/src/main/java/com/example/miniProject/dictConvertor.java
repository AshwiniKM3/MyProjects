package com.example.miniProject;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import edu.stanford.nlp.util.Triple;

public class dictConvertor {
	public static HashSet<HashMap<String, Object>> CleanAndOrganise(Triple<List<String>, List<String>, List<List<String>>> LIST ) {
		Triple<List<String>, List<String>, List<List<String>>> extractedData = LIST;
		HashSet<HashMap<String, Object>> questionSet = new HashSet<>();		
		
		List<String> Answers = extractedData.first();
		List<String> Questions = extractedData.second();
		List<List<String>> Options = extractedData.third();
		
		for(int i=0;i<Answers.size();i++) {
			HashMap<String, Object> question1 = new HashMap<>();  
			question1.put("question", Questions.get(i));
			question1.put("options", Options.get(i));
			question1.put("answer", Answers.get(i));
			questionSet.add(question1);
		}
	//====================================================================================	
		/*Iterator<HashMap<String, Object>> iter = questionSet.iterator();
		while (iter.hasNext()) {
		    HashMap<String, Object> question = iter.next();
		    ArrayList<String> options = (ArrayList<String>) question.get("options");

		  
		    for (int i = 0; i < options.size(); i++) {
		        String option = options.get(i);

		        // Remove "_" and "-"
		        option = option.replace("_", "").replace("-", "");

		        // Convert to lowercase
		        option = option.toLowerCase();

		        // Update the modified option
		        options.set(i, option);
		    }

		    // Check for invalid questions with duplicate options
		    HashSet<String> uniqueOptions = new HashSet<>(options);
		    if (uniqueOptions.size() < 2) {
		        // All or 2 options are the same, remove the question
		        iter.remove();
		    }
		}*/
		

		

		return questionSet;
		
	}
	
	
}