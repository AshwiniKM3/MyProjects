package com.example.miniProject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonParser;
import com.ibm.cloud.sdk.core.security.Authenticator;
import com.ibm.cloud.sdk.core.security.IamAuthenticator;
import com.ibm.watson.natural_language_understanding.v1.NaturalLanguageUnderstanding;
import com.ibm.watson.natural_language_understanding.v1.model.*;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import edu.stanford.nlp.pipeline.CoreDocument;
import edu.stanford.nlp.pipeline.CoreSentence;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.util.CoreMap;
import edu.stanford.nlp.util.Triple;
import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.pipeline.Annotation;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;



public class Watson1{
	 private static NaturalLanguageUnderstanding nluService;
	 private StanfordCoreNLP pipeline;
	    private static String IAM_API_KEY = "_1OVRk8OU37gha9FhXKOBZ_V94KMZBTTwJvEwuUCSnaw";
	    private static String NLU_ENDPOINT_URL = "https://api.us-south.natural-language-understanding.watson.cloud.ibm.com/instances/c35cc03d-9e27-4685-b936-63edec0c76f2";

	    public static void main(String[] args) throws Exception {
	       
	        //==========================================================================================================
	        String pdfFilePath = "C:\\Users\\91944\\OneDrive\\Desktop\\test PDfs\\text11.pdf";
	        PDDocument document = PDDocument.load(new File(pdfFilePath));
	        HashSet<HashMap<String, Object>> extractedData=new HashSet<HashMap<String,Object>>();
            extractedData=Watson1.Generator(document);
	        
	     // Access the individual lists from the Triple
            System.out.println("questionset type: " + extractedData.getClass());
            System.out.println(extractedData);
            HashMap<String, Object> secondQuestion = (HashMap<String, Object>) extractedData.toArray()[1];
            List<String> options = (List<String>) secondQuestion.get("options");
	    }
	    //============================================================================================
	    public static HashSet<HashMap<String, Object>> Generator(PDDocument doc) throws Exception {
	    	 String apiKey = IAM_API_KEY;

		        
		        Authenticator authenticator = new IamAuthenticator(apiKey);

		        
		        nluService = new NaturalLanguageUnderstanding("2021-08-01", authenticator);

		       
		        nluService.setServiceUrl(NLU_ENDPOINT_URL);
	    	List<String> allKeywords = new ArrayList<>();
	        List<String> allSentencesWithBlanks = new ArrayList<>();
	        List<List<String>> allDistractors = new ArrayList<>();
	        
	    	PDDocument document= doc;
	    	PDFTextStripper textStripper = new PDFTextStripper();
	        String pdfText = textStripper.getText(document);

	        // Split paragraphs (assuming paragraphs are separated by empty lines)
	        String[] paragraphs = pdfText.split("\n\n");

	        // Process each paragraph
	        for (String paragraph : paragraphs) {
	            List<String> keywords = Watson1.getKeywordsList(paragraph);
		        System.out.print(keywords);
		if(keywords!= null) {
			keywordsMapping mapper = new keywordsMapping();
		Map<String, String> keywordSentenceMap = mapper.mapKeywordsToSentences(paragraph, keywords);

		//System.out.println(keywordSentenceMap);
		QuestionGenerator mapper1 = new QuestionGenerator();
		Map<String, String> modifiedMap = mapper1.removeDuplicateSentences(keywordSentenceMap);
		//System.out.println(modifiedMap);
		Triple<List<String>, List<String>, List<List<String>>> extractedData = new Triple<>(new ArrayList<>(), new ArrayList<>(), new ArrayList<List<String>>());

		try {
		    extractedData = mapper1.extractKeywordsAndSentences(modifiedMap);
		} catch (IOException e) {
		    // Handle the exception appropriately
		    e.printStackTrace();
		}

		// Access the individual lists from the Triple
		List<String> keywords1 = extractedData.first();
		List<String> sentencesWithBlanks = extractedData.second();
		List<List<String>> distractors = extractedData.third();

		// Use the extracted data as needed
		 allKeywords.addAll(keywords1);
	        allSentencesWithBlanks.addAll(sentencesWithBlanks);
	        allDistractors.addAll(distractors);
		}
		
		else {
			System.out.print("no keywords extracted");
		}
		

	        }
	        document.close();
	        
	       return dictConvertor.CleanAndOrganise(new Triple<>(allKeywords, allSentencesWithBlanks, allDistractors)) ;	       
	    }
	    //==========================================================================================================================
     public static List<String> getKeywordsList(String sen) throws JsonProcessingException{
    	 String paragraph = sen;

     	Features features = new Features.Builder()
     	    .entities(new EntitiesOptions.Builder().build())
     	    .keywords(new KeywordsOptions.Builder().build())
     	    .relations(new RelationsOptions.Builder().build())
     	    .build();

     	AnalyzeOptions parameters = new AnalyzeOptions.Builder()
     	    .text(paragraph)
     	    .features(features)
     	    .build();

     	AnalysisResults results = nluService.analyze(parameters).execute().getResult();
     	//System.out.println(results);
     	//================================================================================   	
    	ObjectMapper mapper = new ObjectMapper();
    	String json;		
			json = mapper.writeValueAsString(results);
			//System.out.print(json);	
			ObjectMapper mapper1 = new ObjectMapper();

			// Parse the JSON string into a Map
			Map<String, Object> resultMap = mapper1.readValue(json, Map.class);
			//System.out.print(resultMap);
			//===========================================================
			List<String[]> textkeywords = getKeywordsByConfidence(resultMap);
			//StringBuilder output = new StringBuilder();

			List<String> keywords = new ArrayList<>();

			for (String[] pair : textkeywords) {
			    String keyword = pair[0];
			    keywords.add(keyword);
			}
            return keywords;
			//System.out.println(output.toString());
		//===============================================================		
     }
     public static List<String[]> getKeywordsByConfidence(Map<String, Object> resultMap) {
    	 if (resultMap != null && resultMap.containsKey("keywords")) {
    		    List<Map<String, Object>> entities = (List<Map<String, Object>>) resultMap.get("keywords");

         // Create a list to store text-confidence pairs
         List<String[]> textConfidencePairs = new ArrayList<>();

         for (Map<String, Object> entity : entities) {
             String text = (String) entity.get("text");
             int count = (Integer) entity.get("count");
             textConfidencePairs.add(new String[]{text, Integer.toString(count)});
         }
         return textConfidencePairs;
     }  
    	 else {
    		 return Collections.emptyList();}
    	 }
     
}