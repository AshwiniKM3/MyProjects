package com.example.miniProject;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class dis {

    private static final String GLOVE_FILE_PATH = "C:\\Users\\91944\\Downloads\\glove.6B\\glove.6B.100d.txt";
    private static final int TOP_N_DISTRACTORS = 5; // Number of distractors to generate

    private static Map<String, double[]> wordVectors;

    public dis() {
        this.wordVectors = new HashMap<>();
    }

    public void loadWordVectors() throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(GLOVE_FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\s+");
                String word = parts[0];
                double[] vector = new double[parts.length - 1];
                for (int i = 1; i < parts.length; i++) {
                    vector[i - 1] = Double.parseDouble(parts[i]);
                }
                wordVectors.put(word, vector);
            }
        }
    }

    public List<String> generateDistractors(String targetWord) {
        List<String> distractors = new ArrayList<>();
        double[] targetVector = wordVectors.get(targetWord);
        if (targetVector == null) {
            System.out.println("Word '" + targetWord + "' not found in the GloVe vectors.");
            return distractors;
        }

        // Calculate cosine similarity with all other words
        PriorityQueue<Map.Entry<String, Double>> queue = new PriorityQueue<>(Comparator.comparingDouble(Map.Entry::getValue));
        for (Map.Entry<String, double[]> entry : wordVectors.entrySet()) {
            String word = entry.getKey();
            double[] vector = entry.getValue();
            if (!word.equals(targetWord)) {
                double similarity = cosineSimilarity(targetVector, vector);
                queue.offer(new AbstractMap.SimpleEntry<>(word, similarity));
                if (queue.size() > TOP_N_DISTRACTORS) {
                    queue.poll();
                }
            }
        }

        // Retrieve top N distractors
        while (!queue.isEmpty()) {
            distractors.add(0, queue.poll().getKey()); // Add at the beginning to maintain descending order
        }

        return distractors;
    }

    private static double cosineSimilarity(double[] vector1, double[] vector2) {
        double dotProduct = 0.0;
        double norm1 = 0.0;
        double norm2 = 0.0;
        for (int i = 0; i < vector1.length; i++) {
            dotProduct += vector1[i] * vector2[i];
            norm1 += Math.pow(vector1[i], 2);
            norm2 += Math.pow(vector2[i], 2);
        }
        return dotProduct / (Math.sqrt(norm1) * Math.sqrt(norm2));
    }

    public static void main(String[] args) {
        dis distractorsGenerator = new dis();
        try {
            distractorsGenerator.loadWordVectors();
            String targetWord = "heart"; // The word for which distractors are to be generated
            List<String> distractors = distractorsGenerator.generateDistractors(targetWord);
            System.out.println("Distractors for '" + targetWord + "':");
            for (String distractor : distractors) {
                System.out.println(distractor);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

