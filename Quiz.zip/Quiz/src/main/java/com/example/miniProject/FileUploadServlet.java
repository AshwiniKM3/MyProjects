package com.example.miniProject;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import javax.servlet.*;
import javax.servlet.http.*;

import org.apache.pdfbox.pdmodel.PDDocument;

import com.google.gson.Gson;

import edu.stanford.nlp.util.Triple;

import javax.servlet.annotation.*;

@WebServlet("/FileUploadServlet")
@MultipartConfig
public class FileUploadServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ServletException | IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ServletException | IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        Connection conn = DatabaseManager.getConnection();
        try {
            String quizName = request.getParameter("FName");
            Part filePart = request.getPart("file");
            InputStream fileContent = filePart.getInputStream();
            PDDocument doc = PDDocument.load(fileContent);
            PrintWriter pw = response.getWriter();
            HashSet<HashMap<String, Object>> questionset = null;
            questionset = Watson1.Generator(doc);

            String quizTableName = "quiz_" + quizName.replaceAll("\\W+", "_");
            PreparedStatement createTableStmt = conn.prepareStatement(
                    "CREATE TABLE " + quizTableName + " (Question VARCHAR(1000), Answer VARCHAR(255), Options VARCHAR(255))");
            createTableStmt.executeUpdate();

            PreparedStatement insertQuestionStmt = conn.prepareStatement(
                    "INSERT INTO " + quizTableName + " (Question, Answer, Options) VALUES (?, ?, ?)");
            for (HashMap<String, Object> question : questionset) {
                String questionText = (String) question.get("question");
                String answer = (String) question.get("answer");
                List<String> options1 = (List<String>) question.get("options");
                insertQuestionStmt.setString(1, questionText);
                insertQuestionStmt.setString(2, answer);
                insertQuestionStmt.setString(3, String.join(",", options1));
                insertQuestionStmt.executeUpdate();
            }

            PreparedStatement insertQuizStmt = conn.prepareStatement(
                    "INSERT INTO QUIZ (QuizName, DateOfGeneration, IDofTable) VALUES (?, NOW(), ?)");
            insertQuizStmt.setString(1, quizName);
            insertQuizStmt.setString(2, quizTableName);
            insertQuizStmt.executeUpdate();

            response.setContentType("text/html");
            pw.println("<html>");
            pw.println("<head>");
            pw.println("<script src='jspdf.min.js'></script>");
            pw.println("</head>");
            pw.println("<body style='background-color: black; color: white;'>");
            pw.println("<b>Quiz generated and stored successfully!</b>");
            pw.println("<div style='margin-top: 20px;'>");
            pw.println("<h1>Questions Generated</h1>");

            for (HashMap<String, Object> secondQuestion : questionset) {
                String q = (String) secondQuestion.get("question");
                List<String> options = (List<String>) secondQuestion.get("options");
                String a = (String) secondQuestion.get("answer");

                pw.println("<div style='font-weight: bold;'>" + q + "</div>");
                pw.println("<ol style='list-style-type: lower-alpha; margin-left: 20px;'>");
                for (String option : options) {
                    pw.println("<li>" + option + "</li>");
                }
                pw.println("</ol>");
                pw.println("<div style='font-style: italic;'>Answer: " + a + "</div>");
            }

            pw.println("</div>");
            pw.println("<button style='margin-top: 20px;' onclick=\"printDiv('container')\">Print</button>");

            pw.println("<script>");
            pw.println("function printDiv(divId) {");
            pw.println("  let printContents = document.getElementById(divId).innerHTML;");
            pw.println("  let originalContents = document.body.innerHTML;");
            pw.println("  document.body.innerHTML = printContents;");
            pw.println("  window.print();");
            pw.println("  document.body.innerHTML = originalContents;");
            pw.println("}");
            pw.println("</script>");
            pw.println("</body>");
            pw.println("</html>");
            //===============================================================================================
            String filename = quizTableName + ".html";
            try (PrintWriter fileWriter = new PrintWriter(new FileWriter("C:/Users/91944/eclipse-workspace/Quiz/src/main/webapp/Quizes/" + filename))) {
                fileWriter.println("<html>");
                fileWriter.println("<head>");
                fileWriter.println("<title>Quiz Questions</title>");
                fileWriter.println("</head>");
                fileWriter.println("<body style='background-color: black; color: white;'>");
                fileWriter.println("<b>Quiz generated and stored successfully!</b>");
                fileWriter.println("<div style='margin-top: 20px;'>");
                fileWriter.println("<h1>Questions Generated</h1>");

                for (HashMap<String, Object> secondQuestion : questionset) {
                    String q = (String) secondQuestion.get("question");
                    List<String> options = (List<String>) secondQuestion.get("options");
                    String a = (String) secondQuestion.get("answer");

                    fileWriter.println("<div style='font-weight: bold;'>" + q + "</div>");
                    fileWriter.println("<ol style='list-style-type: lower-alpha; margin-left: 20px;'>");
                    for (String option : options) {
                        fileWriter.println("<li>" + option + "</li>");
                    }
                    fileWriter.println("</ol>");
                    fileWriter.println("<div style='font-style: italic;'>Answer: " + a + "</div>");
                }

                fileWriter.println("</div>");
                fileWriter.println("</body>");
                fileWriter.println("</html>");
            } catch (IOException e) {
                e.printStackTrace();
            }

        } catch (Exception e) {
            System.out.print(e);
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    System.out.println("Error closing connection: " + e);
                }
                
            }
        }
    }
}