package com.example.miniProject;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/user1")
public class user1 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the username from the session
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");

        // Set response content type
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>User Page</title>");
        out.println("<style>");
        out.println("body { background-color: black; color: white; font-family: Arial, sans-serif; }");
        out.println("table { border-collapse: collapse; width: 100%; border: 2px solid white; }");
        out.println("th, td { padding: 10px; text-align: left; border-bottom: 1px solid white; }");
        out.println("th { background-color: #333; color: white; }");
        out.println("td { background-color: #444; }");
        out.println("h2 { color: #00BFFF; }"); // Adjusted color for h2
        out.println("a { color: #00BFFF; text-decoration: none; }"); // Adjusted color for links
        out.println("a:hover { color: #87CEFA; }"); 
        out.println(" .navbar {background-color: #333;padding: 10px;border-radius: 8px;margin-bottom: 20px;}");// Adjusted hover color for links
        out.println(".navbar a { color: #fff;text-decoration: none; margin-right: 20px;}");
        out.println(".navbar a:hover {text-decoration: underline;}");
        out.println(" .logout-link {float: right;}");
        out.println("</style>");
        out.println("</head><body>");
        out.println("<div class='navbar'>"
        		+ "      <a href='logout' class='logout-link'>Logout</a> "
        		+ "    </div>");

        // Display username
        out.println("<h2>Welcome, " + username + "</h2>");

        // Fetch and display user's quiz reports
        displayQuizReports(username, out);

        // Fetch and display all quizzes
        displayAllQuizzes(out);
        out.println("<p><a href=\"index.jsp\">Take a quiz</a></p>");

        out.println("</body></html>");
    }

    private void displayQuizReports(String username, PrintWriter out) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DatabaseManager.getConnection();
            String Name = "report_" + username.replaceAll("\\W+", "_");
            String query = "SELECT  score, timestamp,name FROM "+ Name;
            statement = connection.prepareStatement(query);
            
            resultSet = statement.executeQuery();

            out.println("<h3>Your Quiz Reports:</h3>");
            out.println("<table border='1'><tr><th>Quiz Name</th><th>Score</th><th>Date</th></tr>");
            while (resultSet.next()) {
            	
                String score = resultSet.getString("score");
                String date = resultSet.getString("timestamp");
                String name = resultSet.getString("name");
                out.println( "<tr><td>"+name+"</td><td>" + score + "</td><td>" + date + "</td></tr>");
            }
            out.println("</table>");
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception appropriately in your application
        } finally {
            // Close resources
            closeResources(connection, statement, resultSet);
        }
    }

    private void displayAllQuizzes(PrintWriter out) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DatabaseManager.getConnection();
            String query = "SELECT * FROM quiz";
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();

            out.println("<h3>All Quizzes:</h3>");
            out.println("<table border='1'><tr>");
            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();
            // Display table headers
            for (int i = 1; i <= columnCount; i++) {
                out.println("<th>" + metaData.getColumnName(i) + "</th>");
            }
            out.println("</tr>");
            // Display table data
            while (resultSet.next()) {
                out.println("<tr>");
                for (int i = 1; i <= columnCount; i++) {
                    out.println("<td>" + resultSet.getString(i) + "</td>");
                }
                out.println("</tr>");
            }
            out.println("</table>");
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception appropriately in your application
        } finally {
            // Close resources
            closeResources(connection, statement, resultSet);
        }
    }

    private void closeResources(Connection connection, PreparedStatement statement, ResultSet resultSet) {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception appropriately in your application
        }
    }
}
