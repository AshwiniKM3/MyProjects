package com.example.miniProject;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/showScores")
public class showScores extends HttpServlet {
	private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String fileName = request.getParameter("Filename");
        List<String> usernames = new ArrayList<>();
        List<String> scores = new ArrayList<>();

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DatabaseManager.getConnection();
            String query = "SELECT username, score FROM " + fileName + "_score"; // Assuming the table name follows this convention
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String username = resultSet.getString("username");
                String score = resultSet.getString("score");
                usernames.add(username);
                scores.add(score);
            }

            // Set the lists as request attributes
            request.setAttribute("usernames", usernames);
            request.setAttribute("scores", scores);

            // Forward the request to the JSP page for rendering
            request.getRequestDispatcher("User.jsp").forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace(); // Handle database exception appropriately
        } finally {
            // Close resources
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace(); // Handle exception appropriately
            }
        }
    }
}