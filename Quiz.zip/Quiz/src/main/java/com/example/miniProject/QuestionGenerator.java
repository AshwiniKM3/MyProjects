package com.example.miniProject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.example.miniProject.distractors;

import edu.stanford.nlp.util.Triple;

public class QuestionGenerator {

	public Map<String, String> removeDuplicateSentences(Map<String, String> keywordSentenceMap) {
	    Map<String, List<String>> sentenceToKeywordsMap = new HashMap<>();
	    Map<String, String> result = new HashMap<>();

	    for (Map.Entry<String, String> entry : keywordSentenceMap.entrySet()) {
	        String sentence = entry.getValue();
	        String keyword = entry.getKey();
	        sentenceToKeywordsMap.computeIfAbsent(sentence, k -> new ArrayList<>()).add(keyword);
	    }
	    // Iterate through sentence map
	    for (Map.Entry<String, List<String>> entry : sentenceToKeywordsMap.entrySet()) {
	        String sentence = entry.getKey();
	        List<String> keywords = entry.getValue();

	        // Choose a random keyword from the list
	        String randomKeyword = keywords.get(0);

	        // Add the chosen pair to the result map
	        result.put(randomKeyword, sentence);
	    }

	    return result;
	}

	public Triple<List<String>, List<String>, List<List<String>>> extractKeywordsAndSentences(Map<String, String> keywordSentenceMap) throws IOException {
        List<String> keywords = new ArrayList<>();
        List<String> sentencesWithBlanks = new ArrayList<>();
        List<List<String>> distractors = new ArrayList<>();
        for (Map.Entry<String, String> entry : keywordSentenceMap.entrySet()) {
            String keyword = entry.getKey();
            String sentence = entry.getValue();
            List<String> keywordDistractors;
            dis distractorsGenerator = new dis();
			try {
				distractorsGenerator.loadWordVectors();
				keywordDistractors = distractorsGenerator.generateDistractors(keyword);;
				 if (keywordDistractors.size() >= 3) {
		                List<String> subString = keywordDistractors.subList(0, 3);  // Now safe to create sublist
		                subString.add(keyword);
		                distractors.add(subString);
		                String maskedSentence = sentence.replaceAll(keyword, "________");
		                keywords.add(keyword);
		                sentencesWithBlanks.add(maskedSentence);
		            } 
		            else {
		                // Handle cases where there are less than 3 distractors (e.g., log a warning or provide alternative options)
		            	continue;
		                // Consider alternative strategies, such as adding fewer distractors or handling it differently
		            }
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
            
           
            
        }

       

        return new Triple<>(keywords, sentencesWithBlanks, distractors);
    }

}
