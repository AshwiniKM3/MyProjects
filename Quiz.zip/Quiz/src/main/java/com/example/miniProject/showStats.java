package com.example.miniProject;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet("/showStats")
public class showStats extends HttpServlet {
	
}