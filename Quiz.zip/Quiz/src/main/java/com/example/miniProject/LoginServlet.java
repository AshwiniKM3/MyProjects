package com.example.miniProject;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    String username = request.getParameter("username");
    String password = request.getParameter("password");

    if (isAdmin(username, password)) {
        // Redirect admin to admin.jsp
        response.sendRedirect("User.jsp");
        
    } else if (isValidUser(username, password)) {
        // Set the username in the session
        HttpSession session = request.getSession();
        session.setAttribute("username", username);
        
        // Redirect regular user to user1 servlet
        response.sendRedirect("user1");
    } else {
        // Redirect to login.jsp with an error parameter
        response.sendRedirect("login.jsp?error=true");
    }
}

    private boolean isAdmin(String username, String password) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DatabaseManager.getConnection();
            String query = "SELECT * FROM admins WHERE username = ? AND password = ?";
            statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);

            resultSet = statement.executeQuery();

            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception appropriately in your application
            return false;
        } finally {
            // Close resources
            closeResources(connection, statement, resultSet);
        }
    }
    private void closeResources(Connection connection, PreparedStatement statement, ResultSet resultSet) {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception appropriately in your application
        }
}
    private boolean isValidUser(String username, String password) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DatabaseManager.getConnection();
            
            // Check if the user is in the users table
            String userQuery = "SELECT * FROM users WHERE username = ? AND password = ?";
            statement = connection.prepareStatement(userQuery);
            statement.setString(1, username);
            statement.setString(2, password);
            resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return true; // User found in users table
            }

            // Check if the user is in the admins table
            String adminQuery = "SELECT * FROM admins WHERE username = ? AND password = ?";
            statement = connection.prepareStatement(adminQuery);
            statement.setString(1, username);
            statement.setString(2, password);
            resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return true; // User found in admins table
            }

            return false; // User not found in any table
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception appropriately in your application
            return false;
        } finally {
            // Close resources
            closeResources(connection, statement, resultSet);
        }
    }
}
