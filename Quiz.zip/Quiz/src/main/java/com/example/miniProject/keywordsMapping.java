package com.example.miniProject;
import edu.stanford.nlp.pipeline.CoreDocument;
import edu.stanford.nlp.pipeline.CoreSentence;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.util.CoreMap;
import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.pipeline.Annotation;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class keywordsMapping {

    private StanfordCoreNLP pipeline;

    public keywordsMapping() throws Exception {
        Properties props = new Properties();
        props.setProperty("annotators", "tokenize, ssplit, pos");
        pipeline = new StanfordCoreNLP(props);
    }

    public Map<String, String> mapKeywordsToSentences(String sentence, List<String> keywords) throws Exception {
        Map<String, String> keywordSentenceMap = new HashMap<>();

        Annotation annotation = pipeline.process(sentence);

        // Access sentences directly from the Annotation object
        List<CoreMap> sentences = annotation.get(CoreAnnotations.SentencesAnnotation.class);

        // Iterate through keywords and find their matching sentences
        for (String keyword : keywords) {
            boolean foundMatch = false;
            for (CoreMap coreSentence : sentences) {
                String currentSentence = coreSentence.toString();
                // Check for keyword match and full stop at the end
                if (currentSentence.contains(keyword) && currentSentence.endsWith(".")) {
                    keywordSentenceMap.put(keyword, currentSentence);
                    foundMatch = true;
                    break; // Stop searching for this keyword
                }
            }
            // If no match found within a sentence ending with a full stop, indicate so
            if (!foundMatch) {
                keywordSentenceMap.put(keyword, "No matching sentence ending with a full stop found.");
            }
        }

        return keywordSentenceMap;
    }
    
}
