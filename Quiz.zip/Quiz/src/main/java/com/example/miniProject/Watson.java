package com.example.miniProject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonParser;
import com.ibm.cloud.sdk.core.security.Authenticator;
import com.ibm.cloud.sdk.core.security.IamAuthenticator;
import com.ibm.watson.natural_language_understanding.v1.NaturalLanguageUnderstanding;
import com.ibm.watson.natural_language_understanding.v1.model.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;


public class Watson {
    private static NaturalLanguageUnderstanding nluService;

    private static String IAM_API_KEY = "_1OVRk8OU37gha9FhXKOBZ_V94KMZBTTwJvEwuUCSnaw";
    private static String NLU_ENDPOINT_URL = "https://api.us-south.natural-language-understanding.watson.cloud.ibm.com/instances/c35cc03d-9e27-4685-b936-63edec0c76f2";

    public static void main(String[] args) {
        String apiKey = IAM_API_KEY;

        
        Authenticator authenticator = new IamAuthenticator(apiKey);

        
        nluService = new NaturalLanguageUnderstanding("2021-08-01", authenticator);

       
        nluService.setServiceUrl(NLU_ENDPOINT_URL);
        WatsonAnalysis();
        }
    //==========================================================================================================================
    public static void WatsonAnalysis() {
    	String paragraph = "In the heart of the Amazon rainforest, lies a hidden river teeming with exotic wildlife. Jaguars stalk the banks, caimans bask on the mudflats, and colorful birds flit through the lush canopy. Scientists believe this river may hold the key to undiscovered species and vital clues about the health of the rainforest ecosystem.";

    	Features features = new Features.Builder()
    	    .entities(new EntitiesOptions.Builder().build())
    	    .keywords(new KeywordsOptions.Builder().build())
    	    .relations(new RelationsOptions.Builder().build())
    	    .build();

    	AnalyzeOptions parameters = new AnalyzeOptions.Builder()
    	    .text(paragraph)
    	    .features(features)
    	    .build();

    	AnalysisResults results = nluService.analyze(parameters).execute().getResult();
    	System.out.println(results);
    	//================================================================================
    	ObjectMapper mapper = new ObjectMapper();
    	String json;
		try {
			json = mapper.writeValueAsString(results);
			//System.out.print(json);
	
			ObjectMapper mapper1 = new ObjectMapper();

			// Parse the JSON string into a Map
			Map<String, Object> resultMap = mapper1.readValue(json, Map.class);
			//System.out.print(resultMap);
			//===========================================================	
			List<String[]> textConfidencePairs = getEntitiesByConfidence(resultMap);

			for (String[] pair : textConfidencePairs) {
			    String text = pair[0];
			    String confidence = pair[1];
			    System.out.println(text + " (" + confidence + ")"+"\n====================");
			}
          //=======================================================================
			

		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//============================================================================================================
    	

    }
//=========================================================================================================================
    public static List<String[]> getEntitiesByConfidence(Map<String, Object> resultMap) {
        List<Map<String, Object>> entities = (List<Map<String, Object>>) resultMap.get("entities");

        // Create a list to store text-confidence pairs
        List<String[]> textConfidencePairs = new ArrayList<>();

        for (Map<String, Object> entity : entities) {
            String text = (String) entity.get("text");
            Double confidence = (Double) entity.get("confidence");
            textConfidencePairs.add(new String[]{text, confidence.toString()});
        }

        return textConfidencePairs;
    }

    
//=========================================================================================================================
   

}
