package com.example.miniProject;

import com.google.gson.*;
import com.ibm.cloud.sdk.core.security.Authenticator;
import com.ibm.cloud.sdk.core.security.IamAuthenticator;
import com.ibm.watson.natural_language_understanding.v1.NaturalLanguageUnderstanding;

import com.ibm.watson.natural_language_understanding.v1.model.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;


public class NLPCall {
    private static NaturalLanguageUnderstanding nluService;

    private static String IAM_API_KEY = "_1OVRk8OU37gha9FhXKOBZ_V94KMZBTTwJvEwuUCSnaw";
    private static String NLU_ENDPOINT_URL = "https://api.us-south.natural-language-understanding.watson.cloud.ibm.com/instances/c35cc03d-9e27-4685-b936-63edec0c76f2";

    public static void main(String[] args) {
    	
        // Set up IBM Watson Natural Language Understanding credentials
        String apiKey = IAM_API_KEY;

        // Create an IAM authenticator.
        Authenticator authenticator = new IamAuthenticator(apiKey);

        // Construct the NLU service client.
        nluService = new NaturalLanguageUnderstanding("2021-08-01", authenticator);

        // Set the NLU service URL.
        nluService.setServiceUrl(NLU_ENDPOINT_URL);

        // Example text to analyze (replace with your paragraph)
        String textToAnalyze = "A patent is a legal document granted by the government to an inventor of a product, device, or process that provides a new or improved way of doing something or a new technical solution to a problem";
        // Analyze the semantic roles using NLU
        AnalyzeOptions parameters1 = new AnalyzeOptions.Builder()
                .text(textToAnalyze)
                .features(new Features.Builder()
                        .semanticRoles(new SemanticRolesOptions.Builder().build())
                        .build())
                .build();

        AnalysisResults response = nluService
                .analyze(parameters1)
                .execute()
                .getResult();

        // Print the NLU results
        System.out.println(response);
        String convertedSentence = convertSentence(response);
        System.out.println("Converted sentence: " + convertedSentence);
        // Generate questions based on the NLU analysis
        List<String> questions = generateQuestions(response);
        System.out.println("Generated questions:");
        for (String question : questions) {
            System.out.println(question);
        }
    }

    private static List<String> generateQuestions(AnalysisResults response) {
        List<String> questions = new ArrayList<>();

        // Parse the JSON response using Gson
        JsonObject jsonResponse = new Gson().fromJson(response.toString(), JsonObject.class);

        // Extract entities directly from the "semantic_roles" array
        JsonArray semanticRoles = jsonResponse.getAsJsonArray("semantic_roles");
        System.out.println(semanticRoles);
        
        

     // Iterate through each object in the array
        for (JsonElement element : semanticRoles) {
            JsonObject semanticRoleObj = element.getAsJsonObject();

            // Access the action and its normalized form
            JsonObject actionObj = semanticRoleObj.getAsJsonObject("action");
            String actionText = actionObj.get("text").getAsString();
            String normalizedAction = actionObj.get("normalized").getAsString();

            // Access the verb object within the action
            JsonObject verbObj = actionObj.getAsJsonObject("verb");
            String verbText = verbObj.get("text").getAsString();
            String verbTense = verbObj.get("tense").getAsString();

            System.out.println("Action: " + actionText);
            System.out.println("Normalized Action: " + normalizedAction);
            System.out.println("Verb: " + verbText);
            System.out.println("Verb Tense: " + verbTense);

            // ... (use the action, normalizedAction, verbText, and verbTense information as needed)

            // You can now use all these aspects to generate even more informative questions
        }


        return questions;
    }
    private static String convertSentence(AnalysisResults response) {
        StringBuilder convertedSentence = new StringBuilder();

        // Parse the JSON response using Gson
        JsonObject jsonResponse = new Gson().fromJson(response.toString(), JsonObject.class);
        JsonArray semanticRoles = jsonResponse.getAsJsonArray("semantic_roles");

        // Iterate through each object in the array
        for (JsonElement element : semanticRoles) {
            JsonObject semanticRoleObj = element.getAsJsonObject();

            // Handle subject (if present)
            JsonObject subjectObj = semanticRoleObj.getAsJsonObject("subject");
            if (subjectObj != null) {
                String subjectText = subjectObj.get("text").getAsString();
                convertedSentence.append(subjectText).append(" ");
            }

            // Handle action and remove object
            JsonObject actionObj = semanticRoleObj.getAsJsonObject("action");
            String normalizedAction = actionObj.get("normalized").getAsString();
            convertedSentence.append("did ").append(normalizedAction).append(" what");

            // Optional comma for separation
            convertedSentence.append(", ");
        }

        // Remove trailing comma and space
        return convertedSentence.substring(0, convertedSentence.length() - 2).trim();
    }

    }