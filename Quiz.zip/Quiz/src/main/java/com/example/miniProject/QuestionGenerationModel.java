package com.example.miniProject;

import java.util.ArrayList;
import java.util.List;

public class QuestionGenerationModel{
	public List <String> QuestionGenerate(){
		List<String> l= new ArrayList<String>();
		return l;
		
	}
	
}