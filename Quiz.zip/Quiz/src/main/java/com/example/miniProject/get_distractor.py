
from sense2vec import Sense2Vec
import sys

# Load the sense2vec model
model_path = r'C:\Users\91944\Downloads\s2v_old'
s2v = Sense2Vec().from_disk(model_path)
from collections import OrderedDict

def sense2vec_get_words(word, s2v):
    output = []
    word = word.lower()
    word = word.replace(" ", "_")

    sense = s2v.get_best_sense(word)
    most_similar = s2v.most_similar(sense, n=50)

    for each_word in most_similar:
        append_word = each_word[0].split("|")[0].replace("_", " ").lower()
        if append_word.lower() != word:
            output.append(append_word.title())

    out = list(OrderedDict.fromkeys(output))
    return out
keyword = sys.argv[1]
# Your existing logic to generate distractors using Sense2Vec
distractors = sense2vec_get_words(keyword, s2v)
for distractor in distractors:
    print(distractor)


