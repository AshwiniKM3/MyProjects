package com.example.miniProject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
public class distractors{
	public static List<String> getDistractorsFromPython(String keyword) throws IOException {
	    List<String> distractors = new ArrayList<>();

	    ProcessBuilder processBuilder = new ProcessBuilder("python", "C:\\Users\\91944\\eclipse-workspace\\miniProject\\src\\main\\java\\com\\example\\miniProject\\get_distractor.py", keyword);
	    Process process = processBuilder.start();

	    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
	    String line;
	    while ((line = reader.readLine()) != null) {
	        distractors.add(line);
	    }

	    return distractors;
	}
	public static void main(String[] args) throws IOException {
	    String keyword = "bloom"; // Example keyword
	    List<String> distractors = null;
		try {
			distractors = getDistractorsFromPython(keyword);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    // Process the distractors as needed
	    for (String distractor : distractors) {
	        System.out.println("Distractor: " + distractor);
	    }
	}}